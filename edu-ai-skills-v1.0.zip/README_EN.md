# 🎓 Edu-AI-Skills

Education Digitalization Research Skills Package for OpenCode

---

## 📖 Overview

Edu-AI-Skills is an OpenCode skills suite designed for **education digitalization research projects**. Based on the "Generative AI Empowered Education Digitalization Research Guide", it provides full-process support for K-12 teachers, university researchers, and education administrators.

From topic selection to final report, this package covers every stage of academic research with integrated GAI (Generative AI) ethics guidance.

## ✨ Features

- **Full-Process Coverage**: From topic selection to project completion
- **7 Core Skills**: Covering all aspects of research projects
- **Academic Standards**: Compliant with research proposal and academic writing standards
- **GAI Integration**: Guidelines for responsible AI tool usage
- **Ready to Use**: Quick installation, immediate use

## 🚀 Quick Start

### Installation

```bash
# Extract to OpenCode skills directory
unzip edu-ai-skills-v1.0.zip -d ~/.config/opencode/skills/
```

### Usage

```text
# Topic Selection
"Help me generate research topics about AI in education" → EDU-AI-001

# Proposal Writing
"Generate proposal framework" → EDU-AI-002

# Literature Analysis
"Analyze this paper" → EDU-AI-003

# Survey Design
"Create a questionnaire" → EDU-AI-004

# Research Optimization
"Research problems encountered" → EDU-AI-005

# Report Writing
"Help me write a paper" → EDU-AI-006

# Ethics Review
"Check AI-generated content" → EDU-AI-007
```

## 📦 Skills Overview

| Skill ID | Name | Function | Scenario |
|----------|------|----------|----------|
| EDU-AI-001 | Topic Generator | Generate research topics aligned with standards | Topic Selection |
| EDU-AI-002 | Proposal Framework | Generate proposal templates with writing tips | Application |
| EDU-AI-003 | Literature Analysis | Analyze papers, summarize research status | Literature Review |
| EDU-AI-004 | Survey Generator | Create questionnaires and interview guides | Data Collection |
| EDU-AI-005 | Research Optimization | Provide method adjustment suggestions | Implementation |
| EDU-AI-006 | Report Polishing | Generate drafts, optimize language | Summary |
| EDU-AI-007 | Ethics Review | Verify AI-generated content compliance | All Stages |

## 📚 Research Directions

- AI Education Platform & Space Construction
- AI Educational Resource Development & Application
- Teacher Digital Literacy Enhancement
- AI-Empowered Teaching Models & Mechanisms
- Regional Education Digitalization Collaboration

## 📄 License

For educational and research purposes only.

## 📬 Contact

For questions or suggestions, please open an Issue.

---

*This package is developed based on "Generative AI Empowered Education Digitalization Research Guide"*
